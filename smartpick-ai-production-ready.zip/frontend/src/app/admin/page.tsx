export default function Admin() {
  return (
    <main>
      <h2 className="text-xl font-semibold mb-2">Admin</h2>
      <p>Admin settings placeholder.</p>
    </main>
  );
}
