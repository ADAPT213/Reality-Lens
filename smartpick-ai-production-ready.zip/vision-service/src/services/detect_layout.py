def detect_layout(file_path: str) -> dict:
    return {"locations": [], "metadata": {}}
