import { Module } from '@nestjs/common';
import { CopilotService } from './copilot.service';
import { CopilotController } from './copilot.controller';
import { ClarityModule } from '../clarity/clarity.module';

@Module({
  imports: [ClarityModule],
  providers: [CopilotService],
  controllers: [CopilotController],
})
export class CopilotModule {}
