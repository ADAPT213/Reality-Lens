export default function Projects() {
  return (
    <main>
      <h2 className="text-xl font-semibold mb-2">Projects</h2>
      <p>Project list placeholder.</p>
    </main>
  );
}
